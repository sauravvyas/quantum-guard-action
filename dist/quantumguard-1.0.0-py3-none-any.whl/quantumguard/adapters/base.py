"""
Abstract base interface for source adapters.

All adapters implement this interface. The orchestrator works exclusively
with SourceAdapter — never with concrete implementations.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.models import ScanTarget


class SourceAdapter(ABC):
    """
    Abstract source adapter.

    Implementations handle file discovery, reading, and writing for
    different source providers (filesystem, GitHub, GitLab, etc.).

    PRIVACY CONTRACT: read_file() returns raw bytes. Callers must never
    transmit this content outside the local process.
    """

    def __init__(self, config: QuantumGuardConfig) -> None:
        self.config = config

    @abstractmethod
    def discover_files(self, target: ScanTarget) -> list[Path]:
        """
        Discover all files matching the target specification.

        Returns absolute paths relative to the local filesystem.
        File content is NOT returned here (privacy boundary).
        """

    @abstractmethod
    def read_file(self, path: Path) -> str:
        """
        Read a file's content as a string.

        Content never leaves the local process.
        """

    @abstractmethod
    def write_file(self, path: Path, content: str) -> None:
        """Write content to a file."""

    def exists(self, path: Path) -> bool:
        """Check if a path exists."""
        return path.exists()

    def read_bytes(self, path: Path) -> bytes:
        """Read raw bytes (for binary files)."""
        return path.read_bytes()
