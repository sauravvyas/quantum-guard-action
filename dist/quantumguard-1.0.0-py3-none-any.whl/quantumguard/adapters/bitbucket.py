"""
Bitbucket adapter — stub for plugin-based extension.
"""
from __future__ import annotations

import logging

from quantumguard.adapters.git import GitAdapter
from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.exceptions import AuthenticationError, PullRequestError

logger = logging.getLogger(__name__)


class BitbucketAdapter(GitAdapter):
    """Bitbucket Cloud source adapter with PR support."""

    def __init__(self, config: QuantumGuardConfig) -> None:
        super().__init__(config)
        if not config.bitbucket_username or not config.bitbucket_app_password:
            raise AuthenticationError(
                "Bitbucket credentials not configured. "
                "Set QUANTUMGUARD_BITBUCKET_USERNAME and QUANTUMGUARD_BITBUCKET_APP_PASSWORD."
            )
        self._username = config.bitbucket_username
        self._password = config.bitbucket_app_password.get_secret_value()

    def create_pull_request(
        self,
        repo: str,
        branch: str,
        title: str,
        body: str,
        base_branch: str = "main",
    ) -> str:
        import httpx

        workspace, slug = repo.split("/", 1)
        url = f"https://api.bitbucket.org/2.0/repositories/{workspace}/{slug}/pullrequests"
        payload = {
            "title": title,
            "description": body,
            "source": {"branch": {"name": branch}},
            "destination": {"branch": {"name": base_branch}},
        }
        response = httpx.post(url, json=payload, auth=(self._username, self._password))
        if response.status_code not in (200, 201):
            raise PullRequestError(f"Bitbucket PR creation failed: {response.text}")
        data = response.json()
        return str(data.get("links", {}).get("html", {}).get("href", ""))
