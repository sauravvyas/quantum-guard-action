"""
Git adapter abstraction layer.

All provider-specific adapters (GitHub, GitLab, etc.) inherit from this.
"""
from __future__ import annotations

import logging
import tempfile
from abc import abstractmethod
from pathlib import Path
from typing import Any

import git as gitpython

from quantumguard.adapters.filesystem import LocalFileSystemAdapter
from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.exceptions import CloneError, PushError
from quantumguard.core.models import ScanTarget

logger = logging.getLogger(__name__)


class GitAdapter(LocalFileSystemAdapter):
    """
    Abstract Git adapter that extends the filesystem adapter with
    Git operations: clone, branch, commit, push, and PR creation.

    Provider-specific adapters override create_pull_request().
    """

    def __init__(self, config: QuantumGuardConfig) -> None:
        super().__init__(config)
        self._repo: gitpython.Repo | None = None
        self._work_dir: Path | None = None
        self._temp_dir: tempfile.TemporaryDirectory | None = None  # type: ignore[type-arg]

    def clone(self, repo_url: str, branch: str | None = None) -> Path:
        """Clone a repository and return the local path."""
        self._temp_dir = tempfile.TemporaryDirectory(prefix="quantumguard_")
        work_dir = Path(self._temp_dir.name)

        logger.info("Cloning %s → %s", repo_url, work_dir)
        try:
            kwargs: dict[str, Any] = {"depth": 1}
            if branch:
                kwargs["branch"] = branch

            self._repo = gitpython.Repo.clone_from(repo_url, work_dir, **kwargs)
            self._work_dir = work_dir
            logger.info("Clone complete: %s", work_dir)
            return work_dir
        except gitpython.GitCommandError as exc:
            raise CloneError(f"Failed to clone {repo_url}: {exc}") from exc

    def create_branch(self, branch_name: str) -> None:
        """Create and checkout a new branch."""
        if self._repo is None:
            raise RuntimeError("No repository — call clone() first")
        self._repo.git.checkout("-b", branch_name)
        logger.info("Created branch: %s", branch_name)

    def commit(self, message: str, paths: list[Path] | None = None) -> None:
        """Stage and commit changes."""
        if self._repo is None:
            raise RuntimeError("No repository — call clone() first")

        if paths:
            for p in paths:
                self._repo.index.add([str(p)])
        else:
            self._repo.git.add("-A")

        self._repo.index.commit(message)
        logger.info("Committed: %s", message)

    def push(self, remote: str = "origin", branch: str | None = None) -> None:
        """Push changes to remote."""
        if self._repo is None:
            raise RuntimeError("No repository — call clone() first")

        ref = branch or self._repo.active_branch.name
        try:
            self._repo.remotes[remote].push(refspec=f"{ref}:{ref}")
            logger.info("Pushed to %s/%s", remote, ref)
        except gitpython.GitCommandError as exc:
            raise PushError(f"Failed to push to {remote}/{ref}: {exc}") from exc

    @abstractmethod
    def create_pull_request(
        self,
        repo: str,
        branch: str,
        title: str,
        body: str,
        base_branch: str = "main",
    ) -> str:
        """Create a pull request. Returns the PR URL."""

    def cleanup(self) -> None:
        """Clean up temporary directory."""
        if self._temp_dir is not None:
            self._temp_dir.cleanup()
            self._temp_dir = None
            self._work_dir = None
            self._repo = None

    def __enter__(self) -> "GitAdapter":
        return self

    def __exit__(self, *args: Any) -> None:
        self.cleanup()
