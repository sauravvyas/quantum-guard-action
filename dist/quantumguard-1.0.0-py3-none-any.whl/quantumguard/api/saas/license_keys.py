"""
License key management router.
"""
from __future__ import annotations

import secrets
import string
import hashlib
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.dependencies import get_current_user
from quantumguard.api.saas.models import LicenseKey, Subscription, User
from quantumguard.api.saas.schemas import (
    CreateLicenseKeyRequest,
    LicenseKeyResponse,
    MessageResponse,
)

router = APIRouter(prefix="/api/v1/license-keys", tags=["license-keys"])


def _generate_key() -> str:
    """Generate a cryptographically secure key in QG-XXXXXXXX-XXXXXXXX-XXXXXXXX format."""
    chars = string.ascii_uppercase + string.digits
    parts = ["".join(secrets.choice(chars) for _ in range(8)) for _ in range(3)]
    return "QG-" + "-".join(parts)


def _get_active_subscription(user: User, db: Session) -> Subscription | None:
    return (
        db.query(Subscription)
        .filter(
            Subscription.user_id == user.id,
            Subscription.status.in_(["active", "trialing"]),
        )
        .first()
    )


@router.get("/verify", response_model=MessageResponse)
def verify_license_key(
    key: str,
    db: Session = Depends(get_db)
) -> MessageResponse:
    """Verify a license key (Used by the public CLI)."""
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    db_key = db.query(LicenseKey).filter(LicenseKey.key_hash == key_hash, LicenseKey.status == "active").first()
    
    if not db_key:
        raise HTTPException(status_code=401, detail="Invalid or inactive license key")
        
    sub = _get_active_subscription(db_key.user, db)
    if not sub:
        raise HTTPException(status_code=401, detail="Active subscription required")
        
    return MessageResponse(message="License is valid")


@router.get("", response_model=list[LicenseKeyResponse])
def list_license_keys(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[LicenseKeyResponse]:
    """Return all license keys belonging to the current user."""
    keys = (
        db.query(LicenseKey)
        .filter(LicenseKey.user_id == current_user.id)
        .order_by(LicenseKey.created_at.desc())
        .all()
    )
    return [LicenseKeyResponse.model_validate(k) for k in keys]


@router.post("", response_model=LicenseKeyResponse, status_code=201)
def create_license_key(
    body: CreateLicenseKeyRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> LicenseKeyResponse:
    """Create a new license key. Requires an active or trialing subscription."""
    sub = _get_active_subscription(current_user, db)
    if sub is None:
        raise HTTPException(
            status_code=402,
            detail="An active subscription is required to create license keys",
        )

    # Check key quota from the plan (Hardcoded to 1 globally)
    max_keys = 1

    active_count = (
        db.query(LicenseKey)
        .filter(LicenseKey.user_id == current_user.id, LicenseKey.status == "active")
        .count()
    )
    if active_count >= max_keys:
        raise HTTPException(
            status_code=403,
            detail=f"You are only allowed a maximum of {max_keys} active key(s). Revoke your existing key first.",
        )

    # Generate unique key
    for _ in range(10):
        key_str = _generate_key()
        key_hash = hashlib.sha256(key_str.encode()).hexdigest()
        if not db.query(LicenseKey).filter(LicenseKey.key_hash == key_hash).first():
            break
    else:
        raise HTTPException(status_code=500, detail="Could not generate a unique key, please retry")

    # The prefix is what we show in the UI later: "QG-ABCD..."
    key_display = key_str[:12] + "••••-••••"
    
    new_key = LicenseKey(
        user_id=current_user.id,
        key_hash=key_hash,
        key_display=key_display,
        name=body.name,
    )
    db.add(new_key)
    db.commit()
    db.refresh(new_key)
    
    # We must return the *full* key exactly once during creation.
    return LicenseKeyResponse(
        id=new_key.id,
        key=key_str,
        name=new_key.name,
        status=new_key.status,
        last_used_at=new_key.last_used_at,
        created_at=new_key.created_at,
        revoked_at=new_key.revoked_at,
    )


@router.delete("/{key_id}", response_model=MessageResponse)
def revoke_license_key(
    key_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> MessageResponse:
    """Revoke (soft-delete) a license key."""
    key = (
        db.query(LicenseKey)
        .filter(LicenseKey.id == key_id, LicenseKey.user_id == current_user.id)
        .first()
    )
    if key is None:
        raise HTTPException(status_code=404, detail="License key not found")
    if key.status == "revoked":
        raise HTTPException(status_code=400, detail="Key is already revoked")

    key.status = "revoked"
    key.revoked_at = datetime.now(timezone.utc)
    db.commit()
    return MessageResponse(message="License key revoked successfully")
