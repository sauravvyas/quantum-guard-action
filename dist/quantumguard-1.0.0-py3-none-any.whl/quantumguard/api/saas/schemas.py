"""
Pydantic schemas (request/response) for the QuantumGuard SaaS API.
"""
from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, EmailStr, Field, field_validator


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

class RegisterRequest(BaseModel):
    name: str = Field(..., min_length=2, max_length=255)
    email: EmailStr
    password: str = Field(..., min_length=8, max_length=128)

    @field_validator("password")
    @classmethod
    def password_strength(cls, v: str) -> str:
        if len(v) < 8:
            raise ValueError("Password must be at least 8 characters")
        return v


class LoginRequest(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 3600


class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    is_active: bool
    is_verified: bool
    created_at: datetime

    model_config = {"from_attributes": True}


class AuthResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = 3600
    user: UserResponse


class UpdateProfileRequest(BaseModel):
    name: str | None = Field(default=None, min_length=2, max_length=255)
    email: EmailStr | None = None


class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8)


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------

class PlanResponse(BaseModel):
    id: str
    name: str
    description: str
    price_monthly: float
    price_yearly: float
    currency: str
    webhook_calls_per_month: int
    max_license_keys: int
    features: list[str]
    is_active: bool
    sort_order: int

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Subscriptions
# ---------------------------------------------------------------------------

class SubscriptionResponse(BaseModel):
    id: str
    status: str
    current_period_start: datetime | None
    current_period_end: datetime | None
    cancel_at_period_end: bool
    plan: PlanResponse | None
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# License Keys
# ---------------------------------------------------------------------------

class LicenseKeyResponse(BaseModel):
    id: str
    key: str
    name: str
    status: str
    last_used_at: datetime | None
    created_at: datetime
    revoked_at: datetime | None

    model_config = {"from_attributes": True}


class CreateLicenseKeyRequest(BaseModel):
    name: str = Field(default="Default", max_length=255)


# ---------------------------------------------------------------------------
# Billing / Stripe
# ---------------------------------------------------------------------------

class CreateCheckoutRequest(BaseModel):
    plan_id: str
    billing_interval: str = Field(default="monthly", pattern="^(monthly|yearly)$")
    success_url: str
    cancel_url: str


class CheckoutSessionResponse(BaseModel):
    checkout_url: str
    session_id: str


class CustomerPortalResponse(BaseModel):
    portal_url: str


class InvoiceResponse(BaseModel):
    id: str
    amount_paid: float
    currency: str
    status: str
    hosted_invoice_url: str | None
    created: datetime
    description: str | None


# ---------------------------------------------------------------------------
# Usage
# ---------------------------------------------------------------------------

class UsageSummaryResponse(BaseModel):
    requests_used: int
    requests_limit: int
    remaining: int
    usage_percent: float
    period_start: datetime | None
    period_end: datetime | None


class UsageEventResponse(BaseModel):
    id: str
    event_type: str
    provider: str | None
    repo: str | None
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Generic
# ---------------------------------------------------------------------------

class MessageResponse(BaseModel):
    message: str


class ErrorResponse(BaseModel):
    detail: str
    code: str | None = None
    extra: dict[str, Any] | None = None
