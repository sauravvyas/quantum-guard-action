"""
Database seeder: populates initial plans on first startup.
"""
from __future__ import annotations

import json
import logging
import os
from dotenv import load_dotenv

load_dotenv()

from sqlalchemy.orm import Session

logger = logging.getLogger("quantumguard.api.saas.seeder")

PLANS = [
    {
        "name": "Trial",
        "description": "Try QuantumGuard free for 30 days.",
        "price_monthly": 0.0,
        "price_yearly": 0.0,
        "currency": "USD",
        "webhook_calls_per_month": 10,
        "max_license_keys": 1,
        "features": json.dumps([
            "10 webhook calls/month",
            "1 repository integration",
            "Python detection",
            "Community support",
            "Trial license key",
        ]),
        "stripe_price_id_monthly": None,
        "stripe_price_id_yearly": None,
        "sort_order": 0,
    },
    {
        "name": "Starter",
        "description": "For individual developers and small teams.",
        "price_monthly": 29.0,
        "price_yearly": 290.0,
        "currency": "USD",
        "webhook_calls_per_month": 500,
        "max_license_keys": 3,
        "features": json.dumps([
            "500 webhook calls/month",
            "3 repository integrations",
            "Python + Node.js detection",
            "Auto-PR remediation",
            "CycloneDX CBOM export",
            "Email support",
        ]),
        "stripe_price_id_monthly": "",  # Set via QUANTUMGUARD_STRIPE_PRICE_STARTER_MONTHLY env
        "stripe_price_id_yearly": "",
        "sort_order": 1,
    },
    {
        "name": "Pro",
        "description": "For growing teams with multiple repositories.",
        "price_monthly": 99.0,
        "price_yearly": 990.0,
        "currency": "USD",
        "webhook_calls_per_month": 5000,
        "max_license_keys": 10,
        "features": json.dumps([
            "5,000 webhook calls/month",
            "Unlimited repositories",
            "All languages (Python, Java, Node, Go, .NET)",
            "Auto-PR remediation",
            "CycloneDX CBOM export",
            "GitHub + GitLab + Bitbucket + Azure DevOps",
            "Priority email support",
            "Audit logs",
        ]),
        "stripe_price_id_monthly": "",
        "stripe_price_id_yearly": "",
        "sort_order": 2,
    },
    {
        "name": "Enterprise",
        "description": "Custom plans for large organizations.",
        "price_monthly": 499.0,
        "price_yearly": 4990.0,
        "currency": "USD",
        "webhook_calls_per_month": 100000,
        "max_license_keys": 100,
        "features": json.dumps([
            "100,000 webhook calls/month",
            "Unlimited repositories",
            "All languages supported",
            "Auto-PR remediation",
            "CycloneDX CBOM export",
            "All SCM integrations",
            "Dedicated Slack support",
            "SLA guarantees",
            "Custom integration",
            "On-premise deployment option",
        ]),
        "stripe_price_id_monthly": "",
        "stripe_price_id_yearly": "",
        "sort_order": 3,
    },
]


def seed_plans(db: Session) -> None:
    """Insert default plans if none exist."""
    from quantumguard.api.saas.models import Plan
    import os

    count = db.query(Plan).count()
    if count > 0:
        logger.debug("Plans already seeded — skipping")
        return

    # Patch in Stripe price IDs from environment
    env_map = {
        "Starter": {
            "monthly": "QUANTUMGUARD_STRIPE_PRICE_STARTER_MONTHLY",
            "yearly": "QUANTUMGUARD_STRIPE_PRICE_STARTER_YEARLY",
        },
        "Pro": {
            "monthly": "QUANTUMGUARD_STRIPE_PRICE_PRO_MONTHLY",
            "yearly": "QUANTUMGUARD_STRIPE_PRICE_PRO_YEARLY",
        },
        "Enterprise": {
            "monthly": "QUANTUMGUARD_STRIPE_PRICE_ENTERPRISE_MONTHLY",
            "yearly": "QUANTUMGUARD_STRIPE_PRICE_ENTERPRISE_YEARLY",
        },
    }

    for plan_data in PLANS:
        name = plan_data["name"]
        if name in env_map:
            plan_data["stripe_price_id_monthly"] = os.environ.get(env_map[name]["monthly"], "")
            plan_data["stripe_price_id_yearly"] = os.environ.get(env_map[name]["yearly"], "")
        plan = Plan(**plan_data)
        db.add(plan)

    db.commit()
    logger.info("Seeded %d plans into database", len(PLANS))
