"""
Billing router: plans, subscription status, Stripe checkout, invoices.
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.orm import Session

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.dependencies import get_current_user
from quantumguard.api.saas.models import Plan, Subscription, User
from quantumguard.api.saas.schemas import (
    CheckoutSessionResponse,
    CreateCheckoutRequest,
    CustomerPortalResponse,
    InvoiceResponse,
    MessageResponse,
    PlanResponse,
    SubscriptionResponse,
)

logger = logging.getLogger("quantumguard.api.saas.billing")
router = APIRouter(prefix="/api/v1/billing", tags=["billing"])

# Read at call time so the server picks up .env changes without restart
_STRIPE_SECRET_KEY_ENV = "QUANTUMGUARD_STRIPE_SECRET_KEY"
_STRIPE_WEBHOOK_SECRET_ENV = "QUANTUMGUARD_STRIPE_WEBHOOK_SECRET"

# In-memory processed event tracker for idempotency
import threading
import time
_processed_events: dict[str, float] = {}
_events_lock = threading.Lock()
_EVENT_TTL = 86400  # Keep event IDs for 24 hours

# Trusted origins for checkout redirect URLs (prevents open redirect)
_TRUSTED_REDIRECT_PREFIXES: list[str] = [
    p.strip()
    for p in os.environ.get(
        "QUANTUMGUARD_SAAS_CORS_ORIGINS",
        "http://localhost:5173,http://localhost:3000",
    ).split(",")
    if p.strip()
]


def _stripe():
    """Lazy-import stripe and raise a clear error if not configured."""
    secret_key = os.environ.get(_STRIPE_SECRET_KEY_ENV, "")
    if not secret_key:
        raise HTTPException(
            status_code=503,
            detail="Payment processing is not configured. Please contact support.",
        )
    import stripe as _stripe_lib
    _stripe_lib.api_key = secret_key
    return _stripe_lib


def _validate_redirect_url(url: str, field_name: str) -> None:
    """Reject redirect URLs not starting with a trusted origin."""
    if not any(url.startswith(prefix) for prefix in _TRUSTED_REDIRECT_PREFIXES):
        raise HTTPException(
            status_code=400,
            detail=f"Invalid {field_name}: must point to a trusted origin.",
        )


def _parse_plan_features(plan: Plan) -> list[str]:
    try:
        return json.loads(plan.features) if plan.features else []
    except Exception:
        return []


def _plan_to_response(plan: Plan) -> PlanResponse:
    return PlanResponse(
        id=plan.id,
        name=plan.name,
        description=plan.description,
        price_monthly=plan.price_monthly,
        price_yearly=plan.price_yearly,
        currency=plan.currency,
        webhook_calls_per_month=plan.webhook_calls_per_month,
        max_license_keys=plan.max_license_keys,
        features=_parse_plan_features(plan),
        is_active=plan.is_active,
        sort_order=plan.sort_order,
    )


# ---------------------------------------------------------------------------
# Plans
# ---------------------------------------------------------------------------

@router.get("/plans", response_model=list[PlanResponse])
def list_plans(db: Session = Depends(get_db)) -> list[PlanResponse]:
    """Return all active plans. Public endpoint — no auth required."""
    plans = db.query(Plan).filter(Plan.is_active.is_(True)).order_by(Plan.sort_order).all()
    return [_plan_to_response(p) for p in plans]


# ---------------------------------------------------------------------------
# Subscription
# ---------------------------------------------------------------------------

@router.get("/subscription", response_model=SubscriptionResponse | None)
def get_subscription(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> SubscriptionResponse | None:
    """Return the user's current subscription."""
    sub = (
        db.query(Subscription)
        .filter(Subscription.user_id == current_user.id)
        .order_by(Subscription.created_at.desc())
        .first()
    )
    if sub is None:
        return None

    plan_resp = _plan_to_response(sub.plan) if sub.plan else None
    return SubscriptionResponse(
        id=sub.id,
        status=sub.status,
        current_period_start=sub.current_period_start,
        current_period_end=sub.current_period_end,
        cancel_at_period_end=sub.cancel_at_period_end,
        plan=plan_resp,
        created_at=sub.created_at,
    )


# ---------------------------------------------------------------------------
# Stripe Checkout
# ---------------------------------------------------------------------------

@router.post("/checkout", response_model=CheckoutSessionResponse)
def create_checkout_session(
    body: CreateCheckoutRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> CheckoutSessionResponse:
    """Create a Stripe Checkout Session for a subscription plan."""
    stripe = _stripe()

    plan = db.query(Plan).filter(Plan.id == body.plan_id, Plan.is_active.is_(True)).first()
    if plan is None:
        raise HTTPException(status_code=404, detail="Plan not found")

    price_id = (
        plan.stripe_price_id_monthly
        if body.billing_interval == "monthly"
        else plan.stripe_price_id_yearly
    )
    if not price_id:
        raise HTTPException(
            status_code=400,
            detail=f"No Stripe price configured for {body.billing_interval} billing on this plan",
        )

    # Ensure Stripe customer
    customer_id = current_user.stripe_customer_id
    if not customer_id:
        customer = stripe.Customer.create(
            email=current_user.email,
            name=current_user.name,
            metadata={"quantumguard_user_id": current_user.id},
        )
        customer_id = customer.id
        current_user.stripe_customer_id = customer_id
        db.commit()

    # Validate redirect URLs to prevent open redirect attacks
    _validate_redirect_url(body.success_url, "success_url")
    _validate_redirect_url(body.cancel_url, "cancel_url")

    session = stripe.checkout.Session.create(
        customer=customer_id,
        payment_method_types=["card"],
        line_items=[{"price": price_id, "quantity": 1}],
        mode="subscription",
        success_url=body.success_url,
        cancel_url=body.cancel_url,
        metadata={"quantumguard_user_id": current_user.id, "plan_id": plan.id},
    )
    return CheckoutSessionResponse(checkout_url=session.url, session_id=session.id)


# ---------------------------------------------------------------------------
# Customer Portal
# ---------------------------------------------------------------------------

@router.post("/portal", response_model=CustomerPortalResponse)
def create_portal_session(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> CustomerPortalResponse:
    """Create a Stripe Customer Portal session for billing management."""
    stripe = _stripe()

    if not current_user.stripe_customer_id:
        raise HTTPException(status_code=400, detail="No billing account found. Please subscribe to a plan first.")

    session = stripe.billing_portal.Session.create(
        customer=current_user.stripe_customer_id,
    )
    return CustomerPortalResponse(portal_url=session.url)


# ---------------------------------------------------------------------------
# Invoices
# ---------------------------------------------------------------------------

@router.get("/invoices", response_model=list[InvoiceResponse])
def list_invoices(
    current_user: User = Depends(get_current_user),
) -> list[InvoiceResponse]:
    """Return the user's Stripe invoice history."""
    stripe = _stripe()

    if not current_user.stripe_customer_id:
        return []

    invoices = stripe.Invoice.list(customer=current_user.stripe_customer_id, limit=20)
    result = []
    for inv in invoices.data:
        result.append(
            InvoiceResponse(
                id=inv.id,
                amount_paid=inv.amount_paid / 100,
                currency=inv.currency.upper(),
                status=inv.status or "unknown",
                hosted_invoice_url=getattr(inv, "hosted_invoice_url", None),
                created=datetime.fromtimestamp(inv.created, tz=timezone.utc),
                description=getattr(inv, "description", None),
            )
        )
    return result


# ---------------------------------------------------------------------------
# Stripe Webhook — MUST be raw body before JSON parsing
# ---------------------------------------------------------------------------

@router.post("/webhook/stripe", include_in_schema=False)
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="Stripe-Signature"),
    db: Session = Depends(get_db),
) -> dict:
    """Handle Stripe webhook events. Validates signature and updates subscription state."""
    webhook_secret = os.environ.get(_STRIPE_WEBHOOK_SECRET_ENV, "")
    secret_key = os.environ.get(_STRIPE_SECRET_KEY_ENV, "")
    if not webhook_secret:
        logger.warning("Stripe webhook secret not configured — rejecting event")
        raise HTTPException(status_code=400, detail="Webhook secret not configured")

    body = await request.body()
    try:
        import stripe as _stripe_lib
        _stripe_lib.api_key = secret_key
        event = _stripe_lib.Webhook.construct_event(body, stripe_signature, webhook_secret)
    except Exception as exc:
        logger.warning("Stripe webhook validation failed: %s", exc)
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    event_type = event["type"]
    event_id = event["id"]
    data = event["data"]["object"]
    
    with _events_lock:
        now = time.monotonic()
        # Clean up old events
        expired = [k for k, v in _processed_events.items() if v < now]
        for k in expired:
            del _processed_events[k]
        
        if event_id in _processed_events:
            logger.info("Ignoring duplicate Stripe event: %s", event_id)
            return {"received": True, "duplicate": True}
        _processed_events[event_id] = now + _EVENT_TTL

    logger.info("Processing Stripe event: %s (id: %s)", event_type, event_id)

    if event_type in ("customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"):
        _handle_subscription_change(data, db)
    elif event_type == "checkout.session.completed":
        _handle_checkout_completed(data, db)

    return {"received": True}


# ---------------------------------------------------------------------------
# Internal webhook handlers
# ---------------------------------------------------------------------------

def _handle_checkout_completed(session: dict, db: Session) -> None:
    metadata = getattr(session, "metadata", None)
    user_id = getattr(metadata, "quantumguard_user_id", None) if metadata else None
    sub_id = getattr(session, "subscription", None)
    if not user_id or not sub_id:
        return
    logger.info("Checkout completed for user %s, subscription %s", user_id, sub_id)


def _handle_subscription_change(stripe_sub: dict, db: Session) -> None:
    stripe_sub_id = getattr(stripe_sub, "id", None)
    customer_id = getattr(stripe_sub, "customer", None)
    status = getattr(stripe_sub, "status", "unknown")

    # Find user
    user = db.query(User).filter(User.stripe_customer_id == customer_id).first()
    if not user:
        logger.warning("No user found for Stripe customer %s", customer_id)
        return

    # Find or create local subscription
    sub = db.query(Subscription).filter(Subscription.stripe_subscription_id == stripe_sub_id).first()
    if sub is None:
        # Try to find by user
        sub = db.query(Subscription).filter(Subscription.user_id == user.id).order_by(Subscription.created_at.desc()).first()
        if sub is None:
            sub = Subscription(user_id=user.id)
            db.add(sub)
        sub.stripe_subscription_id = stripe_sub_id
        sub.stripe_customer_id = customer_id

    sub.status = status
    # Map plan from Stripe price ID
    items = getattr(stripe_sub, "items", None)
    data = getattr(items, "data", []) if items else []
    if data:
        price = getattr(data[0], "price", None)
        price_id = getattr(price, "id", None)
        plan = db.query(Plan).filter(
            (Plan.stripe_price_id_monthly == price_id) | (Plan.stripe_price_id_yearly == price_id)
        ).first()
        if plan:
            sub.plan_id = plan.id

    period_start = getattr(stripe_sub, "current_period_start", None)
    period_end = getattr(stripe_sub, "current_period_end", None)
    if period_start:
        sub.current_period_start = datetime.fromtimestamp(period_start, tz=timezone.utc)
    if period_end:
        sub.current_period_end = datetime.fromtimestamp(period_end, tz=timezone.utc)

    sub.cancel_at_period_end = getattr(stripe_sub, "cancel_at_period_end", False)
    db.commit()
    logger.info("Subscription %s updated to status '%s' for user %s", stripe_sub_id, status, user.id)
