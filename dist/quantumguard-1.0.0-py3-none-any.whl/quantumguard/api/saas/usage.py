"""
Usage tracking router.
"""
from __future__ import annotations

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from quantumguard.api.saas.database import get_db
from quantumguard.api.saas.dependencies import get_current_user
from quantumguard.api.saas.models import Subscription, UsageEvent, User, Plan
from quantumguard.api.saas.schemas import UsageEventResponse, UsageSummaryResponse

router = APIRouter(prefix="/api/v1/usage", tags=["usage"])


@router.get("/me", response_model=UsageSummaryResponse)
def get_usage_summary(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> UsageSummaryResponse:
    """Return API usage summary for the current billing period."""
    sub = (
        db.query(Subscription)
        .filter(Subscription.user_id == current_user.id, Subscription.status.in_(["active", "trialing"]))
        .order_by(Subscription.created_at.desc())
        .first()
    )

    limit = 100  # default
    period_start = None
    period_end = None

    if sub:
        period_start = sub.current_period_start
        period_end = sub.current_period_end
        if sub.plan_id:
            plan = db.query(Plan).filter(Plan.id == sub.plan_id).first()
            if plan:
                limit = plan.webhook_calls_per_month

    # Count usage events in current period
    query = db.query(UsageEvent).filter(UsageEvent.user_id == current_user.id)
    if period_start:
        query = query.filter(UsageEvent.created_at >= period_start)
    if period_end:
        query = query.filter(UsageEvent.created_at <= period_end)

    used = query.count()
    remaining = max(0, limit - used)

    return UsageSummaryResponse(
        requests_used=used,
        requests_limit=limit,
        remaining=remaining,
        usage_percent=round((used / limit) * 100, 1) if limit > 0 else 0.0,
        period_start=period_start,
        period_end=period_end,
    )


@router.get("/me/history", response_model=list[UsageEventResponse])
def get_usage_history(
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
) -> list[UsageEventResponse]:
    """Return recent usage events for the current user."""
    events = (
        db.query(UsageEvent)
        .filter(UsageEvent.user_id == current_user.id)
        .order_by(UsageEvent.created_at.desc())
        .limit(min(limit, 200))
        .all()
    )
    return [UsageEventResponse.model_validate(e) for e in events]
