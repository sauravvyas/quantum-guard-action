"""
Python AST Engine — scans Python source files for legacy cryptographic usage.

Uses:
  - ast (for parsing and detection)
  - libcst (for safe AST-based rewriting)
  - tokenize (for comment-aware scanning)

No Semgrep dependency.
"""
from __future__ import annotations

import ast
import logging
from pathlib import Path

from quantumguard.core.config import QuantumGuardConfig
from quantumguard.core.exceptions import ParseError
from quantumguard.core.models import Finding, SupportedLanguage
from quantumguard.engines.base import LanguageEngine
from quantumguard.engines.python.detectors.rsa_import import RSAImportDetector
from quantumguard.engines.python.detectors.cryptography_rsa import CryptographyRSADetector
from quantumguard.engines.python.detectors.pycryptodome_rsa import PycryptodomeRSADetector
from quantumguard.engines.python.detectors.weak_keys import WeakKeyDetector

logger = logging.getLogger(__name__)


class PythonASTEngine(LanguageEngine):
    """
    Language engine for Python source files.

    Composes multiple detection rules — each in its own module,
    following the Single Responsibility Principle.
    """

    language = "python"
    EXTENSIONS = {".py", ".pyw"}

    def __init__(self, config: QuantumGuardConfig) -> None:
        super().__init__(config)
        self._rules = [
            RSAImportDetector(config),
            CryptographyRSADetector(config),
            PycryptodomeRSADetector(config),
            WeakKeyDetector(config),
        ]

    def discover(self, root: Path) -> list[Path]:
        """Return all .py files under root."""
        return [p for p in root.rglob("*") if p.suffix in self.EXTENSIONS and p.is_file()]

    def scan(self, file_path: Path, content: str) -> list[Finding]:
        """
        Parse the file and run all detection rules.

        PRIVACY: content is processed in-memory only.
        """
        if not content.strip():
            return []

        try:
            tree = ast.parse(content, filename=str(file_path))
        except SyntaxError as exc:
            raise ParseError(str(file_path), str(exc)) from exc

        findings: list[Finding] = []
        for rule in self._rules:
            try:
                rule_findings = rule.detect(file_path, content, tree)
                findings.extend(rule_findings)
            except Exception as exc:
                logger.warning(
                    "Rule '%s' failed on %s: %s",
                    rule.rule_id,
                    file_path,
                    exc,
                )

        return findings

    def add_rule(self, rule: "DetectionRule") -> None:
        """Dynamically add a detection rule (for plugins)."""
        from quantumguard.engines.base import DetectionRule
        self._rules.append(rule)

    @property
    def rule_ids(self) -> list[str]:
        return [r.rule_id for r in self._rules]
