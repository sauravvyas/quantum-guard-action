"""
Detection Rule: cryptography library RSA usage

Detects RSA usage via the `cryptography` package.

Patterns detected:
  from cryptography.hazmat.primitives.asymmetric import rsa
  from cryptography.hazmat.primitives.asymmetric.rsa import generate_private_key
  rsa.generate_private_key(...)
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from quantumguard.core.constants import CWE_QUANTUM_VULNERABLE, CWE_WEAK_CRYPTOGRAPHY
from quantumguard.core.models import Algorithm, Finding, Severity, SupportedLanguage
from quantumguard.engines.base import DetectionRule

_CRYPTO_RSA_MODULES = {
    "cryptography.hazmat.primitives.asymmetric",
    "cryptography.hazmat.primitives.asymmetric.rsa",
    "cryptography.hazmat.primitives.asymmetric.padding",
}

_RSA_NAMES = {"rsa", "generate_private_key", "generate_public_key", "RSAPrivateKey", "RSAPublicKey"}


class CryptographyRSADetector(DetectionRule):
    """Detects RSA usage via the `cryptography` package."""

    rule_id = "PQC-PY-002"
    description = "RSA usage via `cryptography` hazmat primitives detected"

    def detect(self, file_path: Path, content: str, tree: Any) -> list[Finding]:
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                module = node.module or ""
                if module not in _CRYPTO_RSA_MODULES:
                    continue

                # Check if any imported name is RSA-related
                imported_names = [alias.name for alias in node.names]
                rsa_names = [n for n in imported_names if n in _RSA_NAMES or n == "*"]

                if not rsa_names and not (module.endswith(".rsa")):
                    continue

                findings.append(
                    Finding(
                        file=file_path,
                        line=node.lineno,
                        column=node.col_offset,
                        end_line=node.end_lineno,
                        language=SupportedLanguage.PYTHON,
                        algorithm=Algorithm.RSA,
                        library="cryptography",
                        rule_id=self.rule_id,
                        severity=Severity.HIGH,
                        recommendation=(
                            "Replace `cryptography` RSA primitives with "
                            "`quantumguard_pqc.cryptography_patch` which provides "
                            "Hybrid PQC (ML-KEM-768 + RSA-3072) drop-in replacements."
                        ),
                        description=self.description,
                        cwe=[CWE_QUANTUM_VULNERABLE, CWE_WEAK_CRYPTOGRAPHY],
                        metadata={
                            "module": module,
                            "names": imported_names,
                        },
                    )
                )

        return findings
