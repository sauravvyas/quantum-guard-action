"""
Detection Rule: PyCryptodome / PyCrypto RSA usage

Patterns detected:
  from Crypto.PublicKey import RSA
  from Cryptodome.PublicKey import RSA
  RSA.generate(...)
  RSA.import_key(...)
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Any

from quantumguard.core.constants import CWE_QUANTUM_VULNERABLE, CWE_WEAK_CRYPTOGRAPHY
from quantumguard.core.models import Algorithm, Finding, Severity, SupportedLanguage
from quantumguard.engines.base import DetectionRule

_PYCRYPTO_MODULES = {
    "Crypto.PublicKey",
    "Cryptodome.PublicKey",
}


class PycryptodomeRSADetector(DetectionRule):
    """Detects RSA usage via PyCryptodome / PyCrypto."""

    rule_id = "PQC-PY-003"
    description = "RSA usage via PyCryptodome/PyCrypto detected"

    def detect(self, file_path: Path, content: str, tree: Any) -> list[Finding]:
        findings: list[Finding] = []

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom):
                module = node.module or ""
                if module not in _PYCRYPTO_MODULES:
                    continue

                imported_names = [alias.name for alias in node.names]
                if "RSA" not in imported_names and "*" not in imported_names:
                    continue

                lib_name = "pycryptodome" if "Cryptodome" in module else "pycrypto"
                findings.append(
                    Finding(
                        file=file_path,
                        line=node.lineno,
                        column=node.col_offset,
                        end_line=node.end_lineno,
                        language=SupportedLanguage.PYTHON,
                        algorithm=Algorithm.RSA,
                        library=lib_name,
                        rule_id=self.rule_id,
                        severity=Severity.HIGH,
                        recommendation=(
                            f"Replace `from {module} import RSA` with "
                            "`from quantumguard_pqc.pycryptodome_patch import RSA` "
                            "to use the Hybrid PQC shim."
                        ),
                        description=self.description,
                        cwe=[CWE_QUANTUM_VULNERABLE, CWE_WEAK_CRYPTOGRAPHY],
                        metadata={"module": module, "names": imported_names},
                    )
                )

        return findings
