"""
Plugin bootstrap — registers all built-in engines, adapters, and remediators.

This module is imported once at startup. Third-party plugins register
themselves via setuptools entry points (no modification to this file needed).
"""
from __future__ import annotations

import logging

from quantumguard.core.registry import (
    load_plugins_from_entry_points,
    register_adapter,
    register_engine,
    register_remediator,
)

logger = logging.getLogger(__name__)


def bootstrap() -> None:
    """Register all built-in plugins and load third-party plugins."""
    _register_builtin_engines()
    _register_builtin_adapters()
    _register_builtin_remediators()
    load_plugins_from_entry_points()
    logger.info("Plugin bootstrap complete")


def _register_builtin_engines() -> None:
    from quantumguard.engines.python.engine import PythonASTEngine

    register_engine("python", PythonASTEngine)
    logger.debug("Registered built-in engine: python")

    # Stub registrations for future languages — plugins override these
    # register_engine("java", JavaEngine)   # install quantumguard-java
    # register_engine("node", NodeEngine)   # install quantumguard-node
    # register_engine("go", GoEngine)       # install quantumguard-go
    # register_engine("dotnet", DotNetEngine) # install quantumguard-dotnet


def _register_builtin_adapters() -> None:
    from quantumguard.adapters.filesystem import LocalFileSystemAdapter
    from quantumguard.adapters.github import GitHubAdapter
    from quantumguard.adapters.gitlab import GitLabAdapter
    from quantumguard.adapters.bitbucket import BitbucketAdapter
    from quantumguard.adapters.azure_devops import AzureDevOpsAdapter

    register_adapter("filesystem", LocalFileSystemAdapter)
    register_adapter("github", GitHubAdapter)
    register_adapter("gitlab", GitLabAdapter)
    register_adapter("bitbucket", BitbucketAdapter)
    register_adapter("azure_devops", AzureDevOpsAdapter)


def _register_builtin_remediators() -> None:
    from quantumguard.engines.python.remediator import PythonRemediator

    register_remediator("python", PythonRemediator)
