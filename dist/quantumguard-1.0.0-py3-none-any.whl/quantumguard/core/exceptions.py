"""
Custom exception hierarchy for QuantumGuard.
"""
from __future__ import annotations


class QuantumGuardError(Exception):
    """Base exception for all QuantumGuard errors."""

    def __init__(self, message: str, details: dict | None = None) -> None:
        super().__init__(message)
        self.details = details or {}


# ---------------------------------------------------------------------------
# Registry errors
# ---------------------------------------------------------------------------


class RegistryError(QuantumGuardError):
    """Raised when a registry operation fails."""


class EngineNotFoundError(RegistryError):
    """Raised when no engine is registered for a language."""

    def __init__(self, language: str) -> None:
        super().__init__(
            f"No engine registered for language: '{language}'. "
            f"Install the appropriate plugin or check supported languages."
        )
        self.language = language


class AdapterNotFoundError(RegistryError):
    """Raised when no adapter is registered for a provider."""

    def __init__(self, provider: str) -> None:
        super().__init__(
            f"No adapter registered for provider: '{provider}'. "
            f"Install the appropriate plugin or check supported adapters."
        )
        self.provider = provider


class RemediatorNotFoundError(RegistryError):
    """Raised when no remediator is registered for a language."""

    def __init__(self, language: str) -> None:
        super().__init__(
            f"No remediator registered for language: '{language}'."
        )
        self.language = language


# ---------------------------------------------------------------------------
# Adapter errors
# ---------------------------------------------------------------------------


class AdapterError(QuantumGuardError):
    """Base class for adapter errors."""


class AuthenticationError(AdapterError):
    """Raised when authentication fails with a remote provider."""


class RepositoryNotFoundError(AdapterError):
    """Raised when a target repository cannot be found."""


class FileAccessError(AdapterError):
    """Raised when file access fails."""


class CloneError(AdapterError):
    """Raised when repository cloning fails."""


class PushError(AdapterError):
    """Raised when pushing to remote fails."""


class PullRequestError(AdapterError):
    """Raised when PR creation fails."""


# ---------------------------------------------------------------------------
# Engine / detection errors
# ---------------------------------------------------------------------------


class EngineError(QuantumGuardError):
    """Base class for engine errors."""


class ParseError(EngineError):
    """Raised when source file parsing fails."""

    def __init__(self, file: str, reason: str) -> None:
        super().__init__(f"Failed to parse '{file}': {reason}")
        self.file = file
        self.reason = reason


class DetectionRuleError(EngineError):
    """Raised when a detection rule encounters an error."""


# ---------------------------------------------------------------------------
# Remediation errors
# ---------------------------------------------------------------------------


class RemediationError(QuantumGuardError):
    """Base class for remediation errors."""


class RewriteError(RemediationError):
    """Raised when source rewriting fails."""


class DependencyUpdateError(RemediationError):
    """Raised when dependency file update fails."""


# ---------------------------------------------------------------------------
# CBOM errors
# ---------------------------------------------------------------------------


class CBOMError(QuantumGuardError):
    """Raised when CBOM generation fails."""


# ---------------------------------------------------------------------------
# Configuration errors
# ---------------------------------------------------------------------------


class ConfigurationError(QuantumGuardError):
    """Raised when configuration is invalid or incomplete."""
