"""
Dependency Injection Container.

Provides centralized, type-safe dependency management.
"""
from __future__ import annotations

import logging
from typing import Any, TypeVar, overload

logger = logging.getLogger(__name__)

T = TypeVar("T")


class Container:
    """
    Simple dependency injection container.

    Supports singleton and factory registrations.
    """

    def __init__(self) -> None:
        self._singletons: dict[str, Any] = {}
        self._factories: dict[str, Any] = {}
        self._resolved: dict[str, Any] = {}

    def register_singleton(self, key: str, instance: Any) -> None:
        """Register a pre-constructed singleton instance."""
        self._singletons[key] = instance
        logger.debug("Container: registered singleton '%s'", key)

    def register_factory(self, key: str, factory: Any) -> None:
        """Register a factory callable that creates instances on demand."""
        self._factories[key] = factory
        logger.debug("Container: registered factory '%s'", key)

    def resolve(self, key: str) -> Any:
        """Resolve a dependency by key."""
        if key in self._singletons:
            return self._singletons[key]

        if key in self._resolved:
            return self._resolved[key]

        if key in self._factories:
            instance = self._factories[key]()
            self._resolved[key] = instance
            return instance

        raise KeyError(f"No registration found for key: '{key}'")

    def resolve_optional(self, key: str) -> Any | None:
        """Resolve a dependency or return None if not registered."""
        try:
            return self.resolve(key)
        except KeyError:
            return None

    def has(self, key: str) -> bool:
        return key in self._singletons or key in self._factories or key in self._resolved

    def reset(self) -> None:
        """Reset resolved instances (useful for testing)."""
        self._resolved.clear()


# Global container instance
_container: Container | None = None


def get_container() -> Container:
    """Get or create the global DI container."""
    global _container
    if _container is None:
        _container = Container()
    return _container


def reset_container() -> None:
    """Reset the global container (primarily for testing)."""
    global _container
    _container = None
