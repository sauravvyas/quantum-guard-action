"""
Core domain models for QuantumGuard.

Privacy note: These models contain ONLY metadata (file paths, line numbers,
algorithm names). Source code content is NEVER stored or transmitted.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field, model_validator


class Severity(str, Enum):
    """Finding severity levels aligned with CVSS."""

    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class Algorithm(str, Enum):
    """Cryptographic algorithms that may require migration."""

    RSA = "RSA"
    DSA = "DSA"
    ECDSA = "ECDSA"
    DH = "DH"
    SHA1 = "SHA1"
    MD5 = "MD5"
    DES = "DES"
    TRIPLE_DES = "3DES"
    RC4 = "RC4"
    ECB_MODE = "ECB_MODE"
    WEAK_KEY = "WEAK_KEY"
    UNKNOWN = "UNKNOWN"


class SupportedLanguage(str, Enum):
    """Supported programming languages."""

    PYTHON = "python"
    JAVA = "java"
    NODE = "node"
    GO = "go"
    DOTNET = "dotnet"


class SupportedAdapter(str, Enum):
    """Supported source adapters."""

    FILESYSTEM = "filesystem"
    GIT = "git"
    GITHUB = "github"
    GITLAB = "gitlab"
    BITBUCKET = "bitbucket"
    AZURE_DEVOPS = "azure_devops"


class Finding(BaseModel):
    """
    A single cryptographic finding.

    PRIVACY: Contains ONLY file path, line numbers, and algorithm metadata.
    Source code content is NEVER included.
    """

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    file: Path
    line: int
    column: int = 0
    end_line: int | None = None
    language: SupportedLanguage
    algorithm: Algorithm
    library: str
    rule_id: str
    severity: Severity
    recommendation: str
    description: str = ""
    cwe: list[str] = Field(default_factory=list)
    confidence: float = Field(default=1.0, ge=0.0, le=1.0)
    remediated: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = {"use_enum_values": True}


class ScanTarget(BaseModel):
    """Represents a scan target — a file or directory to analyze."""

    path: Path
    language: SupportedLanguage | None = None
    adapter: SupportedAdapter = SupportedAdapter.FILESYSTEM
    include_patterns: list[str] = Field(default_factory=lambda: ["**/*"])
    exclude_patterns: list[str] = Field(
        default_factory=lambda: [
            "**/.git/**",
            "**/node_modules/**",
            "**/__pycache__/**",
            "**/*.pyc",
            "**/venv/**",
            "**/.venv/**",
            "**/build/**",
            "**/dist/**",
        ]
    )
    recursive: bool = True
    max_file_size_bytes: int = 5 * 1024 * 1024  # 5 MB


class ScanResult(BaseModel):
    """Results from a complete scan operation."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    target: ScanTarget
    findings: list[Finding] = Field(default_factory=list)
    files_scanned: int = 0
    files_with_findings: int = 0
    errors: list[str] = Field(default_factory=list)
    duration_seconds: float = 0.0
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None

    @property
    def total_findings(self) -> int:
        return len(self.findings)

    @property
    def critical_findings(self) -> list[Finding]:
        return [f for f in self.findings if f.severity == Severity.CRITICAL.value]

    @property
    def findings_by_severity(self) -> dict[str, list[Finding]]:
        result: dict[str, list[Finding]] = {}
        for finding in self.findings:
            sev = str(finding.severity)
            result.setdefault(sev, []).append(finding)
        return result

    @property
    def findings_by_file(self) -> dict[Path, list[Finding]]:
        result: dict[Path, list[Finding]] = {}
        for finding in self.findings:
            result.setdefault(finding.file, []).append(finding)
        return result


class RemediationPlan(BaseModel):
    """Plan for remediating a set of findings."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    scan_result_id: str
    findings: list[Finding]
    target_branch: str = "quantumguard/pqc-migration"
    commit_message: str = "chore(security): migrate RSA to Hybrid PQC via QuantumGuard"
    pr_title: str = "[QuantumGuard] Migrate legacy cryptography to Post-Quantum Cryptography"
    pr_body: str = ""
    dry_run: bool = False
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class RemediationResult(BaseModel):
    """Result of a remediation operation."""

    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    plan_id: str
    files_modified: list[Path] = Field(default_factory=list)
    findings_remediated: list[str] = Field(default_factory=list)  # Finding IDs
    errors: list[str] = Field(default_factory=list)
    pr_url: str | None = None
    branch_name: str | None = None
    duration_seconds: float = 0.0
    dry_run: bool = False
    success: bool = False
    completed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class PluginInfo(BaseModel):
    """Metadata about a registered plugin."""

    name: str
    version: str
    description: str
    plugin_type: str  # engine | adapter | remediator
    author: str = ""
    supported_languages: list[str] = Field(default_factory=list)
    supported_platforms: list[str] = Field(default_factory=list)


class SystemHealth(BaseModel):
    """System health check results."""

    quantumguard_version: str
    python_version: str
    registered_engines: list[str]
    registered_adapters: list[str]
    registered_remediators: list[str]
    dependencies: dict[str, bool]
    issues: list[str] = Field(default_factory=list)

    @property
    def is_healthy(self) -> bool:
        return not self.issues


class CBOMComponent(BaseModel):
    """A component in the Cryptographic Bill of Materials."""

    bom_ref: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: str = "library"
    name: str
    version: str = ""
    purl: str = ""
    description: str = ""


class CBOMCryptoAsset(BaseModel):
    """A cryptographic asset in the CBOM."""

    bom_ref: str = Field(default_factory=lambda: str(uuid.uuid4()))
    type: str = "algorithm"
    name: str
    algorithm_properties: dict[str, Any] = Field(default_factory=dict)
    related_findings: list[str] = Field(default_factory=list)


class CBOM(BaseModel):
    """CycloneDX 1.6 compatible Cryptographic Bill of Materials."""

    bom_format: str = "CycloneDX"
    spec_version: str = "1.6"
    version: int = 1
    serial_number: str = Field(default_factory=lambda: f"urn:uuid:{uuid.uuid4()}")
    metadata: dict[str, Any] = Field(default_factory=dict)
    components: list[CBOMComponent] = Field(default_factory=list)
    crypto_assets: list[CBOMCryptoAsset] = Field(default_factory=list)
    findings: list[Finding] = Field(default_factory=list)
    dependencies: list[dict[str, Any]] = Field(default_factory=list)
    generated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
