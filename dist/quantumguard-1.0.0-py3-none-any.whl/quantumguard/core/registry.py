"""
Registry System — Plugin-based extensibility via registries.

The Registry pattern allows languages and adapters to be added as plugins
without ever modifying core files.

Usage:
    from quantumguard.core.registry import register_engine, ENGINE_REGISTRY

    register_engine("python", PythonASTEngine)
    engine_cls = ENGINE_REGISTRY["python"]
"""
from __future__ import annotations

import importlib.metadata
import logging
from typing import TYPE_CHECKING, Any, TypeVar

if TYPE_CHECKING:
    from quantumguard.adapters.base import SourceAdapter
    from quantumguard.engines.base import LanguageEngine, Remediator

logger = logging.getLogger(__name__)

T = TypeVar("T")

# ---------------------------------------------------------------------------
# Core registries — never modify these directly; use register_* functions
# ---------------------------------------------------------------------------

ENGINE_REGISTRY: dict[str, type[Any]] = {}
ADAPTER_REGISTRY: dict[str, type[Any]] = {}
REMEDIATOR_REGISTRY: dict[str, type[Any]] = {}


# ---------------------------------------------------------------------------
# Registration helpers
# ---------------------------------------------------------------------------


def register_engine(language: str, engine_cls: type[Any]) -> None:
    """Register a language engine for a given language identifier."""
    key = language.lower()
    if key in ENGINE_REGISTRY and ENGINE_REGISTRY[key] is not engine_cls:
        logger.warning("Overwriting engine registry for language '%s'", key)
    ENGINE_REGISTRY[key] = engine_cls
    logger.debug("Registered engine: %s -> %s", key, engine_cls.__name__)


def register_adapter(provider: str, adapter_cls: type[Any]) -> None:
    """Register a source adapter for a given provider identifier."""
    key = provider.lower()
    if key in ADAPTER_REGISTRY and ADAPTER_REGISTRY[key] is not adapter_cls:
        logger.warning("Overwriting adapter registry for provider '%s'", key)
    ADAPTER_REGISTRY[key] = adapter_cls
    logger.debug("Registered adapter: %s -> %s", key, adapter_cls.__name__)


def register_remediator(language: str, remediator_cls: type[Any]) -> None:
    """Register a remediator for a given language identifier."""
    key = language.lower()
    if key in REMEDIATOR_REGISTRY and REMEDIATOR_REGISTRY[key] is not remediator_cls:
        logger.warning("Overwriting remediator registry for language '%s'", key)
    REMEDIATOR_REGISTRY[key] = remediator_cls
    logger.debug("Registered remediator: %s -> %s", key, remediator_cls.__name__)


# ---------------------------------------------------------------------------
# Discovery via entry-points (plugin architecture)
# ---------------------------------------------------------------------------


def load_plugins_from_entry_points() -> None:
    """
    Auto-discover and register plugins via setuptools entry points.

    Third-party plugins declare entry points in their pyproject.toml:
        [project.entry-points."quantumguard.engines"]
        myplugin = "mypkg.engine:MyEngine"
    """
    _load_group("quantumguard.engines", register_engine)
    _load_group("quantumguard.adapters", register_adapter)
    _load_group("quantumguard.remediators", register_remediator)


def _load_group(group: str, register_fn: Any) -> None:
    try:
        eps = importlib.metadata.entry_points(group=group)
        for ep in eps:
            try:
                cls = ep.load()
                register_fn(ep.name, cls)
                logger.info("Loaded plugin '%s' from entry point '%s'", ep.name, group)
            except Exception as exc:
                logger.error(
                    "Failed to load plugin '%s' from group '%s': %s",
                    ep.name,
                    group,
                    exc,
                )
    except Exception as exc:
        logger.debug("Entry point group '%s' not found: %s", group, exc)


# ---------------------------------------------------------------------------
# Registry introspection
# ---------------------------------------------------------------------------


def get_registered_engines() -> list[str]:
    return list(ENGINE_REGISTRY.keys())


def get_registered_adapters() -> list[str]:
    return list(ADAPTER_REGISTRY.keys())


def get_registered_remediators() -> list[str]:
    return list(REMEDIATOR_REGISTRY.keys())


def get_engine(language: str) -> type[Any] | None:
    return ENGINE_REGISTRY.get(language.lower())


def get_adapter(provider: str) -> type[Any] | None:
    return ADAPTER_REGISTRY.get(provider.lower())


def get_remediator(language: str) -> type[Any] | None:
    return REMEDIATOR_REGISTRY.get(language.lower())
